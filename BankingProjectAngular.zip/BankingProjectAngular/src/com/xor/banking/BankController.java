package com.xor.banking;


public class BankController {

}
